// 변수를 선언합니다.
let nan = Number("안녕하세요");
let undefinedVariable;
// 부정 연산자를 두 번 사용합니다.
console.log(!!0);
console.log(!!nan);
console.log(!!"");
console.log(!!null);
console.log(!!undefinedVariable);
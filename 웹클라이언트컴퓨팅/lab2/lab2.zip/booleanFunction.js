// 변수를 선언합니다.
let nan = Number("안녕하세요");
let undefinedVariable;
// Boolean() 함수를 사용합니다.
console.log(Boolean(0));
console.log(Boolean(nan));
console.log(Boolean(""));
console.log(Boolean(null));
console.log(Boolean(undefinedVariable));
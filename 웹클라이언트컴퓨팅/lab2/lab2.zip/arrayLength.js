let array = [52, 273, 32, 65, 103];
console.log(array);
console.log(array.length);

  console.log("(lab1-1) console.log() -- Hello World! 나는 <서민석>이다.");
  document.write("<h1> (lab1-2) document.write() -- 하하하, 여기도 <서민석>!!! </h1>");
  alert("(lab1-2) alert() -- <소프트웨어학부>(<20181625>)");

﻿
